# QuizApplication
 Android Quiz application using Android Studio
 <br>
 <br>
  The main Interface
 <br>
 

 <img src="images/1.jpg" height="300px">
 <br>
  Questions
 <br>


 <img src="images/2.jpg" height="300px">
 
 <img src="images/3.jpg" height="300px">
 
  <br>
  Result
 <br>

<img src="images/4.jpg" height="300px">
    
